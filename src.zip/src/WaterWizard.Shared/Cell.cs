namespace WaterWizard.Shared;

public class Cell(CellState cellState)
{ //test
    public CellState CellState { get; set; } = cellState;
}
