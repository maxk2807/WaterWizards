﻿namespace WaterWizard.Shared;

public class Class1 { }
