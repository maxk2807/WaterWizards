namespace WaterWizard.Shared;

public enum CardType
{
    Damage,
    Utility,
    Environment,
    Healing,
}
