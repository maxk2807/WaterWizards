namespace WaterWizard.Shared;

public enum CellState
{
    Empty,
    Ship,
    Rock,
    Hit,
    Miss,
    Unknown,
    Thunder,
}
