namespace WaterWizard.Shared;

public class Ship { }
