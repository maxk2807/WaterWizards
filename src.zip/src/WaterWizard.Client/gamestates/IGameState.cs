namespace WaterWizard.Client.gamestates;

public interface IGameState
{
    void UpdateAndDraw(GameStateManager manager);
}
