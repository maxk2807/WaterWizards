namespace WaterWizard.Client.gamescreen.ships;

public enum ShipType
{
    DEFAULT,
    MERCHANT,
}
