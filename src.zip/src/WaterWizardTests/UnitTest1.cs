namespace WaterWizardTests;

public class UnitTest1
{
    /// <summary>
    /// Example test to verify that the pipeline is working correctly.
    /// This test will always pass.
    /// </summary>
    [Fact]
    public void Test1()
    {
        Assert.True(true);
    }
}
